package Resolver;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

public class Test1 extends AppUtils
{
	//public static WebDriver driver;
	@Test
	public void login() throws Throwable
	{
		{	
		 WebElement emailelement=	driver.findElement(By.id("inputEmail"));
		 boolean  isemaildisplays=emailelement.isDisplayed();
		 Assert.assertTrue(isemaildisplays);

		 WebElement paswordelement=driver.findElement(By.id("inputPassword"));
		boolean isPwddisplays= paswordelement.isDisplayed();
		 
		Assert.assertTrue(isPwddisplays,"Password Element not Displayed");

		emailelement.sendKeys("srinivasbalasani@gmail.com");
		paswordelement.sendKeys("srinivas@4791");
		
		Thread.sleep(2000);
		driver.findElement(By.xpath("//button[@type='submit']")).click();
		}

		
	}
}	
	

