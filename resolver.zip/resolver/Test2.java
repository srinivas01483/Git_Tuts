package Resolver;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

public class Test2 extends AppUtils{

	@Test
	public void checklist_element()
	{
	//WebElement groupElement=driver.findElement(By.xpath("//ul[@class='list-group']")).findElements(By.tagName(null));
	List<WebElement> eleList=driver.findElements(By.xpath("//ul[@class='list-group']/li"));
	Assert.assertEquals(eleList.size(), 3);
	
	//WebElement listValue=driver.findElement(By.xpath("//li[@class=\"list-group-item justify-content-between\"][2]"));
	String listActValue=eleList.get(1).getText();
	//Assert.assertEquals(listActValue, "List Item 2");
	if(listActValue.contains("List Item 2")) {
		System.out.println("element matched "+listActValue);
	}else
	{
		System.out.println("Element not matched " +listActValue);
	}
	
	WebElement badgeValue=driver.findElement(By.xpath("//ul[@class=\"list-group\"]/li[2]/span"));
	Assert.assertEquals(badgeValue.getText(), "6");
	//List<WebElement>groupElementlist=groupElement.findElements("li");
	}
}
