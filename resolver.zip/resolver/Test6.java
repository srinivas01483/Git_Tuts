package Resolver;

import static org.testng.Assert.assertTrue;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Test;

import dev.failsafe.internal.util.Assert;

public class Test6 extends AppUtils{
	
	@Test
	public void checkdata() 
	
	{
		
	WebElement tabledata=driver.findElement(By.xpath("//table[@class='table table-bordered table-dark']"));
	
	
	List<WebElement>rows=tabledata.findElements(By.tagName("tr"));
	
	for(int i=0;i<rows.size();i++)
	{
	List<WebElement>cols=rows.get(i).findElements(By.tagName("td"));
	
	
	for(WebElement element:cols)
	{
		boolean foundElement=element.getText().equalsIgnoreCase("Ventosanzap");
		
		
		if(foundElement)
		{
		
			
			assertTrue(foundElement);
			System.out.println("element found");
		}
	}
		
	}
		
	}
}
