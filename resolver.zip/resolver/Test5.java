package Resolver;

import static org.testng.Assert.assertFalse;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

public class Test5 extends AppUtils{
	@Test 
	public  void check_button() throws Throwable {
		WebElement chkbutton=driver.findElement(By.xpath("//div[@id='test-5-div']//button[@class='btn btn-lg btn-primary']"));
		
		WebDriverWait wait =new WebDriverWait(driver,Duration.ofSeconds(10));
		wait.until(ExpectedConditions.visibilityOf(chkbutton));
		chkbutton.click();
		
		WebElement alertMsg=driver.findElement(By.id("test5-alert"));
		
		System.out.println(alertMsg.getText());
		
		boolean chkbuttonDisbled=chkbutton.isEnabled();
		System.out.println(chkbuttonDisbled);
		assertFalse(chkbuttonDisbled,"chk button element is disbled");
		
		
	}

}
