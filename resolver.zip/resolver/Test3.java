package Resolver;

import static org.testng.Assert.assertEquals;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

public class Test3 extends AppUtils {
	@Test
	public void Option() throws InterruptedException
	{
	WebElement buttonelement=driver.findElement(By.id("dropdownMenuButton"));
	String optiontext=buttonelement.getText();
	assertEquals(optiontext, "Option 1");
	buttonelement.click();
	
	List<WebElement>buttonlist=driver.findElements(By.xpath("//*[@class='dropdown-item']"));
	
	for(WebElement button:buttonlist)
	{
		if(button.getText().equals("Option 3"))
		{
			
			button.click();
		}
		
	}

		
	}
	
}
