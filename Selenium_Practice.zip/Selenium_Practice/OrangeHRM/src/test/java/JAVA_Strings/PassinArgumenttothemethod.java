package JAVA_Strings;

public class PassinArgumenttothemethod {

public static void method1(String p)
{
	
System.out.println("call method1");
//p="ajja";
}

public  void method2()
{
	
System.out.println("Call method2");

}
			
public static void main(String [] args)
{
	
PassinArgumenttothemethod.method1("method1 executed");
PassinArgumenttothemethod p=new PassinArgumenttothemethod();
p.method2();
}
		
	}


