package JAVA_Strings;

public class Remove_DuplicateCharacters {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String str="hello";
		 String result="";
		   
		   for(int i=0;i<str.length();i++)
		   {
		       char ch=str.charAt(i);
		       
		       if(result.indexOf(ch)==-1)
		       {
		           result +=ch;
		           
		       }
		       
		   }
		   System.out.println(result);
		   
		
				   }
		

	}


