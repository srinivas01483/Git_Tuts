package JAVA_Strings;

import java.util.HashSet;
import java.util.Set;

public class UniqueCharacters {

	public static void main(String[] args) {

		
		String name = "india";
        String unique = "";
       char[] chararray=name.toCharArray();
       
       for(char c:chararray)
       {
    	  // System.out.println(c);
           
    	   if(name.indexOf(c)==name.lastIndexOf(c))
    	   {
    		   unique +=c;
    		   
    	   }
    	   
       }
        
System.out.println(unique);
	}

}
