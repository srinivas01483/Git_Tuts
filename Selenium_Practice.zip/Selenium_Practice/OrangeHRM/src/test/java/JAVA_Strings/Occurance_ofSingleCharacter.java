package JAVA_Strings;

public class Occurance_ofSingleCharacter {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	
	String str="srinivas";
	
		char ch='s';
		int count=0;
		
		for(int i=0;i<str.length();i++)
		{
			
			if(str.charAt(i)==ch)
			{
				count++;
			}
			//System.out.println("Number of Occurance "+ch+ " "+count);
		}
		System.out.println("Number of Occurance "+ch+ " "+count);
		
	}

}
