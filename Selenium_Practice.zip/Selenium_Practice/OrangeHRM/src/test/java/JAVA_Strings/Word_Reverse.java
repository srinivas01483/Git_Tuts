package JAVA_Strings;

public class Word_Reverse {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		  String str="hello world";
		     String[] words  =str.split(" ");
		     
		    String rev_string="";
		    for(String w:words) 
		    {
		        System.out.println(w);
		    String rev_word="";
		        for(int i=w.length()-1;i>=0;i--)
		        {
		            
		            rev_word=rev_word+w.charAt(i);
		            
		        }
		        rev_string=rev_string+rev_word+" ";
		    }
		       
		       System.out.println(rev_string);
		       
		      
		       StringBuilder sb=new StringBuilder();
		       sb.append(rev_string);
		       sb.reverse();
		       System.out.println(sb);
			     
	}

}
