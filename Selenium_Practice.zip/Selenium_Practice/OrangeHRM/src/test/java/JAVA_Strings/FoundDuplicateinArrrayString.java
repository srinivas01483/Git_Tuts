package JAVA_Strings;

public class FoundDuplicateinArrrayString {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
 
		String[] str= {"java","c","python","java","c"};
		
		for(int i=0;i<str.length;i++)
		{
			boolean isduplicate=false;
			
			for(int j=i+1;j<str.length;j++)
			{
				if(str[i]==str[j])
				{
					isduplicate=true;
					break;
					
				}
				
			}
			
			
			if(isduplicate)
			{
			System.out.println(str[i]);
			}
		}
		
		
	}

}
