package JAVA_Strings;

public class RemoveWhiteSpaces {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String str="java   programing   language   developed";
		System.out.println("Before removing white spaces "+str);
		String str_space=str.replaceAll("\\s", "");
		System.out.println("after removing white spaces  "+str_space);
		
	}

}
