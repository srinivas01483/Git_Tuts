	package JAVA_Strings;

public class SplitText {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String text="10-04-1991";
		String[] printtext=text.split("-");
		
	for(String e:printtext)
	{
		System.out.println(e);
	}
		
		
	}

}

//output
//10
//04
//1991
