package JAVA_Strings;

import java.util.HashMap;
import java.util.Map;

public class DuplicateWordsinSTring {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str="hello hello srinivas";
		String[] words=str.split(" ");
		
		Map<String,Integer>map=new HashMap<String,Integer>();
		
		for(String w:words)
		{
			System.out.println(w);
			
			if(!map.containsKey(w))
			{
				map.put(w, 1);
				
			}
			else
			{
				int count=map.get(w);
				
				map.put(w, count+1);
				
			}
		}
		
		System.out.println(map);
	}

}
