package JAVA_Strings;

public class RemoveJunk {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String s="@#!#$!$!$%$%!*&_+_+_)* srinivas 1483 #$@#$@$%123";
		
		s=s.replaceAll("[^a-zA-Z0-9]", "");
		
		System.out.println(s);
		
		
		String r="Welcome  to  hydearbad";
		r=r.replaceAll("\\s", "");
		System.out.println(r);
	}

}
