package JAVA_Strings;

public class RemoveVowels {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String str="srinivasu";
		
		String result="";
		
	char[] chararry=str.toCharArray();	
	System.out.println(chararry);
	
	for(char ch:chararry)
	{
		if(!(ch=='a' || ch=='e' ||ch=='i' || ch=='o' || ch=='u'))
			
		{
			result +=ch;
			
		}
		
	}
		System.out.println(result);
	}

}
