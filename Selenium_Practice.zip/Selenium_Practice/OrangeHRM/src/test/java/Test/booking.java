package Test;

import java.time.Duration;

import org.checkerframework.checker.calledmethods.qual.EnsuresCalledMethods.List;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.github.bonigarcia.wdm.WebDriverManager;

public class booking {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub

		
		WebDriverManager.chromedriver().setup();		
				WebDriver driver = new ChromeDriver();		
				driver.manage().window().maximize();
				driver.manage().deleteAllCookies();
				driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
				
		driver.get("https://bookcart.azurewebsites.net/");
		driver.findElement(By.xpath("//mat-toolbar-row/div[3]/button[2]/span[2]")).click();

		driver.findElement(By.xpath("//form/mat-form-field[1]/div[1]/div/div[2]/input")).sendKeys("Srinivas@1");
		driver.findElement(By.xpath("//form/mat-form-field[2]/div[1]/div/div[2]/input")).sendKeys("Srinivas@1483");
		driver.findElement(By.xpath("//form[1]/mat-card-actions[1]/button[1]/span[2]")).click();
	
		 WebElement SearchBox=driver.findElement(By.xpath("//mat-toolbar-row/div[2]/app-search/form/input"));
		 SearchBox.sendKeys("Harry");
		 
		java.util.List<WebElement>keywordlist =driver.findElement(By.xpath("/html/body/div[3]/div/div")).findElements(By.tagName("mat-option"));
		System.out.println(keywordlist.size()) ;
		for(WebElement p:keywordlist)
		{
			System.out.println(p.getText().equals(keywordlist));
			
		}
		
		/*
		SearchBox.sendKeys("Harry Potter and the Prisoner of Azkaban");
		WebElement selectelement=driver.findElement(By.xpath("/html/body/div[3]/div/div/div/mat-option/span"));
		selectelement.click();
		 Thread.sleep(2000);
		 
		 WebElement addcartbutton=driver.findElement(By.xpath("//span[contains(text(),'Add to Cart')]"));
		 addcartbutton.click();
		 SearchBox.clear();
		 
		 SearchBox.sendKeys("robbie");
		
		 selectelement.click();
		 Thread.sleep(2000);
		 addcartbutton.click();
		 
		 */
		 
	}

}
