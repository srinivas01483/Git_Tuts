package Test;

public class abc {
	
	
	public  void methodA()
	{
		
		System.out.println("Hello world");	
		
	
	}

	static void methodB() {
		
		System.out.println("Hello");
		
	}
	
	
	public void methodC()
	{
	
		
	}
}
