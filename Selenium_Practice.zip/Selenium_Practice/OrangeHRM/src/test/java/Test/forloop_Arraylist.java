package Test;

import java.util.ArrayList;
import java.util.List;

public class forloop_Arraylist {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		List<String>vehicle=new ArrayList<>();
		
		vehicle.add("Bike1");
		vehicle.add("Bike2");
		vehicle.add("Bike3");		
		vehicle.add("Bike4");
		
		//System.out.println(vehicle.size());
		
		for(int i=0;i<vehicle.size();i++)
		{
			System.out.println(vehicle.get(i));
			
			
		}
	}
	

}
