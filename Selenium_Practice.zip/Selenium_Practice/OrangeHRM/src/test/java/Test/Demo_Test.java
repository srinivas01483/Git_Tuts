package Test;

import org.testng.annotations.Test;

public class Demo_Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.out.println("Hello");
		
		
		
	}

}
