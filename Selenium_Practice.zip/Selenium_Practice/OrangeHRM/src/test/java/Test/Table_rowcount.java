package Test;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Table_rowcount {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
WebDriverManager.chromedriver().setup();
		
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.get("https://www.railyatri.in/time-table");
		
		WebElement irctctable =driver.findElement(By.xpath("//body/div[@id='homepage-main-container']/div[2]/div[2]/div[1]/div[1]"));
		
		List<WebElement>row=driver.findElements(By.tagName("tr"));
		
		int rowcount=row.size();
		System.out.println(rowcount);
		
		for(int i=1;i<row.size();i++)
		{
			List<WebElement>cols=row.get(i).findElements(By.xpath("td"));
			String TrainNo=cols.get(0).getText();
			String TrainName=cols.get(1).getText();
			
			System.out.println("list of " +TrainNo +" "+TrainName);
			
		}
		
		
	}

}
