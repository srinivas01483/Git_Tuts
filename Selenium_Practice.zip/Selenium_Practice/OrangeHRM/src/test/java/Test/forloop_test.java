package Test;

public class forloop_test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int[]marks= {40,50,60,70,80,90};
		
		int i;
		for(i=0;i<marks.length;i++)
		{
			System.out.println(marks[i]);
			
		}
		
		
	}

}
