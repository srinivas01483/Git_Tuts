package Test;

import java.util.Scanner;

public class Nested_if_String {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		String course;
		
		System.out.println("Enter course code");
		
		Scanner sc =new Scanner(System.in);
		course=sc.nextLine();
		
		if(course.equalsIgnoreCase("s"))
		{
			System.out.println("Selenium");
			
		}else
			if(course.equalsIgnoreCase("j"))
			{
				System.out.println("Java");
			}else if(course.equalsIgnoreCase("p"))
			{
				System.out.println("Python");
			}else
			{
				System.out.println("invalid course");
			}
	}

}
