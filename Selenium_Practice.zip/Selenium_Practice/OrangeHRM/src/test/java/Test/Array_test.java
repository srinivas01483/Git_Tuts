package Test;

public class Array_test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//syntax datatype[]carlist={value1,value2,value3....valuen);
		
		String[]carlist= {"car1","car2","car3"};
		
		int count =carlist.length;
		System.out.println("No of elements "+count);
		
		System.out.println(carlist[0]);
		System.out.println(carlist[1]);
		System.out.println(carlist[2]);
		
		//Replacing an Array
		carlist[0]="new car";
		System.out.println(carlist[0]);

	}

}
