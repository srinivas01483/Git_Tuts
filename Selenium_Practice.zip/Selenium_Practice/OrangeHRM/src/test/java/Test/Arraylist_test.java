package Test;

import java.util.ArrayList;

public class Arraylist_test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ArrayList<String>carlist;
		
		carlist=new ArrayList<String>();
		carlist.add("car1");
		carlist.add("car2");
		carlist.add("car3");
		carlist.add("car4");
		
		System.out.println(carlist.size());
	
		System.out.println(carlist.get(0));
		
		carlist.set(1, "New Car");
		
		System.out.println(carlist.get(1));
		
		carlist.add("car5");
		System.out.println(carlist.size());
		
		//Removing Existing Element in list
		carlist.remove(0);
		System.out.println(carlist.get(0));
		
		carlist.contains("car2");
	}

}
