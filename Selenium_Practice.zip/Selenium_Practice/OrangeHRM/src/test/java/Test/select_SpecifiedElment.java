package Test;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class select_SpecifiedElment {

	public static void main(String[] args) {
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
		
		driver.get("http://orangehrm.qedgetech.com");
		
		driver.findElement(By.id("txtUsername")).sendKeys("Admin");
		driver.findElement(By.id("txtPassword")).sendKeys("Qedge123!@#");
		driver.findElement(By.id("btnLogin")).click();
		
		driver.findElement(By.linkText("PIM")).click();
		driver.findElement(By.linkText("Add Employee")).click();
		driver.findElement(By.linkText("Employee List")).click();
		
		String emp_status="Automation";
		
		WebElement element =driver.findElement(By.id("empsearch_employee_status"));
		
		Select cat=new Select(element);
		
		try {
			cat.selectByVisibleText(emp_status);
			{
				System.out.println(emp_status +"is item present in the list,test pass");
			}
		} catch (Exception e) {
			// TODO: handle exception
			System.out.println(emp_status+"is item not present in the list,Test Fail");
		}
		
		
				

	}

}
