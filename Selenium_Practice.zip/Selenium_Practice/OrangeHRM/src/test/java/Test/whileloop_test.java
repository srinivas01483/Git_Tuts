package Test;

import java.util.Scanner;

public class whileloop_test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String course;
		System.out.println("do you want to continue");
		
		Scanner sc=new Scanner(System.in);
		course=sc.nextLine();
		
		while(course.equalsIgnoreCase("y"))
		{
			System.out.println("loop executed");
			System.out.println("do you want to continue");
			course=sc.nextLine();
			
		}
		System.out.println("loop ended");
		
		
		
	}

}
