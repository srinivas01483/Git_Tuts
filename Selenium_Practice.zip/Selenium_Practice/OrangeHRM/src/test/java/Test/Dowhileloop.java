package Test;

import java.util.Scanner;

public class Dowhileloop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String c;
		do
		{
			System.out.println("loop executed");
			System.out.println("Do you want to continue");
			Scanner sc =new Scanner(System.in);
			c=sc.nextLine();
			
			
		}
	while(c.equalsIgnoreCase("y"));
		
		System.out.println("loop ended");
		
	}

}
