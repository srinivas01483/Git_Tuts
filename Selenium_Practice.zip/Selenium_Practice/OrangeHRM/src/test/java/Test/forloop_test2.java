package Test;

public class forloop_test2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String[]carlist= {"car1","car2","car3","car4"};
		System.out.println(carlist.length);
		
		for(int i=0;i<carlist.length;i++)
		{
			
			System.out.println(carlist[i]);
		}
		
	}

}
