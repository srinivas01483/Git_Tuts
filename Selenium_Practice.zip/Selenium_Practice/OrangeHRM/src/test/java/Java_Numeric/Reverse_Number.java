package Java_Numeric;

public class Reverse_Number {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int num=11;
		int org_num=num;
		int rev=0;
		
		while(num!=0)  
		{
			rev=rev*10+num%10;   //0+1234%10=4   1234%10=123  4 is eliminated
			num=num/10; //1234/10=123
		}
		System.out.println(rev);
		
		if(org_num==rev)
		{
			System.out.println("Given number is Palindrome number "+rev);
		}else
		{
			System.out.println("Given number is not a Palindrome number "+rev);
		}
	}

}
