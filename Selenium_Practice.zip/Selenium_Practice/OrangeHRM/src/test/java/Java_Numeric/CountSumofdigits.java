package Java_Numeric;

public class CountSumofdigits {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int num=12345;
		int sum=0;
		while(num>0)
		{
			sum=sum+num%10;  // reminder is 5
			num=num/10; //1234 5 is eliminated
			
		}
		
		System.out.println("count of digits sum "+sum);
	}

}
