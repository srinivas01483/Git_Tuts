package Java_Numeric;

public class MaxandMinvalueReturn {

	public static void main(String[] args) {
		
		int[]a= {20,23,53,58,56,888,55};
		int max=a[0];
		int min=a[0];
		
		for(int i=0;i<=a.length-1;i++) //0
		{
			if(max<a[i])
			{
				max=a[i];
			}
			
			if(min>a[i])
					{
				min=a[i];
					}
		}
		
		System.out.println(max);
		System.out.println(min);
		
		
	}

}
