package Java_Numeric;

public class ConcateMethod {

	private static final String Srinivas = null;

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		//System.out.println("one ".concat("two ").concat("Three"));4791
		
	/*	
		String a="srinivas";
		String b="Balasani";
		int c=4791;
		System.out.println(a+" "+b+ " "+c);
		
		*/
		String a="srinivas";
		String b="";
		
		System.out.println(a.startsWith("sri"));
		System.out.println(a.startsWith("ni"));
		//ends with
		
		System.out.println(a.endsWith("vas"));
		
		//
	}

}
