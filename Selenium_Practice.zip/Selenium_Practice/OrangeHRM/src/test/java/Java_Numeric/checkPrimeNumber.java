package Java_Numeric;

import java.util.Scanner;

public class checkPrimeNumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	Scanner sc=new Scanner(System.in);
	
	System.out.println("Enter Any number");
	int num=sc.nextInt();
	
	boolean isprime=true;
	if(num>1)
	{
		for(int j=2;j<=num;j++)
			
		{
			
			if(num%2==0)
			{
				isprime=false;
			}
		}
		
	}else
	{
		
		isprime=false;
	}
	if(isprime)
	{
		System.out.println(num+ " is a prime number");
	}else
	{
		
		System.out.println(num+ " is not a prime number");
	}
		
	}

}
