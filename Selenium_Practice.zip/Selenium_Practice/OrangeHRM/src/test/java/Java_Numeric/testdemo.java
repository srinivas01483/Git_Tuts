package Java_Numeric;

import java.util.Scanner;

import org.openqa.selenium.WebElement;

public class testdemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	String str="@#!##$srinivas 1483";
	str=str.replaceAll("[^a-zA-Z0-9]", "");
	System.out.println(str);
	}	
}
