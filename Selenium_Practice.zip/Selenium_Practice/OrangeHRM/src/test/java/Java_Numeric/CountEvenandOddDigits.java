package Java_Numeric;

import org.openqa.selenium.devtools.v118.debugger.Debugger.EvaluateOnCallFrameResponse;

public class CountEvenandOddDigits {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int num=123456;
		int even_count=0;
		int odd_count=0;
		
		while(num>0) //123456 12345
		{
			int reminder=num%10; //6 5
			if(reminder%2==0)
			{
				
				even_count++; //1
			}else
				
				if(reminder%2!=0)
				{
					odd_count++; //1
				}
			
			
			num=num/10;  //12345 eliminated 6, 1234 eliminated 5
			
		}
		System.out.println("count od even is"+even_count);
		System.out.println("count od even is"+odd_count);
	}

}
