package Java_Numeric;

public class tocharArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
  String a="Srinivas Balasani";
 
  char[] b=a.toCharArray();
 
 for(int i=0;i<b.length;i++)
 {
	System.out.println(b[i]);
	 //System.out.println(data);
 }
		
 System.out.println(a.toUpperCase());
 
	}

}
