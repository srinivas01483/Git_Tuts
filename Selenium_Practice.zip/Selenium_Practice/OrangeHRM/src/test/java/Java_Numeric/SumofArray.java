package Java_Numeric;

public class SumofArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String str="amma";
		String rev="";
		
		for(int i=str.length()-1;i>=0;i--)
		{
			
			rev=rev+str.charAt(i);
		}
		
		System.out.println(rev);
		
		if(str.equalsIgnoreCase(rev))
		{System.out.println("Given string is palindrome");}
		
		//Sum of array
		
		int[] a= {2,3,5};
		int sum=0;
		
		for(int i=0;i<a.length;i++)
				{
			
			sum=sum+a[i];
				}
		
		System.out.println(sum);
			}

}
