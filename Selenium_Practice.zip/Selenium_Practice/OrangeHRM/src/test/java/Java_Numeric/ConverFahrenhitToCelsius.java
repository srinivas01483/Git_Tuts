package Java_Numeric;

import java.util.Scanner;

public class ConverFahrenhitToCelsius {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		double fahrenhit=98;
		double celsius=((fahrenhit-32)*5)/9;
		System.out.println(celsius);
		
		
		//celsius to fahrenhit
	
		
		double c=36;
		double f1=(c*9/5)+32;
		System.out.println(f1);
		
		
		// scanner class
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Faherhit temp");
		
		double faherhit=sc.nextInt();
		double celsius1=(faherhit-32)*5/9;
		
		System.out.println(celsius1);
	
		
		System.out.println("Enter Celsius value");
		double celsius2=sc.nextInt();
		double fahernhit1=celsius2*9/5+32;
		
		System.out.println(fahernhit1);
		
		
		
		
		
		
	
		
	}

}
