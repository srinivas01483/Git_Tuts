package Java_Numeric;

import java.util.Currency;
import java.util.Scanner;

import org.checkerframework.checker.units.qual.Length;

public class FoundDuplicateinArrray {

	public static void main(String[] args) {
	
//remove  series  //0 1 1 2 3 5 8 13 21 34
		//duplicate number in array
		
		int arr[]= {2,5,6,8,9,5,4};
		
		for(int i=0;i<arr.length;i++)
		{
			boolean isduplicate=false;
			
			for(int j=i+1;j<arr.length;j++)
			{
				if(arr[i]==arr[j])
				{
					isduplicate=true;
					break;
					
				}
				
				
			}
			
		if(!isduplicate)
		{
			System.out.println(arr[i]);
		}
			
		}
				
	}
	
	}
	
