package Java_Numeric;

public class greatestnumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int a=45000,b=8800,c=500,d=900;		
		if(a>b & a>c & a>d)
		{
			System.out.println("a is the greatest number");
		}else
			if(b>c & b>d)
		{
				System.out.println("b is the greatest number");
		}else
			if(c>d)
		{
			System.out.println("c is the greatest number");
		}
			else
			{
				System.out.println("d is the greatest number");
			}
		
	}

}
