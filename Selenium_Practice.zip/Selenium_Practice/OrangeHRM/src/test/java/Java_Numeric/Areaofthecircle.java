package Java_Numeric;

import java.util.Scanner;

import org.testng.annotations.Test;

public class Areaofthecircle {
	
	@Test
	public void circlr()
	{
		
		final double pie=3.14;
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the radius value");
		int r=sc.nextInt();
		double c=(pie*r*r);
		
		System.out.println(c);
	}

}
