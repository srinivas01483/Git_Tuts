package Java_Numeric;

public class SwapTwoNumbers {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int a=2,b=3,c;
		/*
		c=a;
		a=b;
		b=c;
		
		System.out.println("a is "+a);
		System.out.println("b is "+b);
		*/
		
		// swappimg two numbers without usig third varaible
		
		a=a+b;
		b=a-b;
		a=a-b;
		
		System.out.println("a is "+a);
		System.out.println("b is "+b);
		
		
	}

}
