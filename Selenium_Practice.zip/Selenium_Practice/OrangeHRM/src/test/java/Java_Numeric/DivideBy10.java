package Java_Numeric;

public class DivideBy10 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//To print 1-1000 numbers divisibly by 10
		
		int i;
		for(i=1;i<=1000;i++)
		{
			if(i%10==0)
			{
				System.out.println(i);			}
		}
		
		//to print 1-100
		
		for(int j=1;j<=100;j++)
		{
			System.out.println(j);
		}
		
		//to print 100-1
		
		for(int a=100;a>=1;a--)
		{
			System.out.println(a);
		}
	}

}
