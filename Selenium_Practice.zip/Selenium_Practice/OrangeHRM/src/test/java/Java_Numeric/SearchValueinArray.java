package Java_Numeric;

import java.util.Scanner;

public class SearchValueinArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		int[]a= {12,45,8,7,4,5,3,89,10};
		Scanner sc=new Scanner(System.in);
		
	System.out.println("Enter value");
	int Searchnumber=sc.nextInt();
	boolean found=false;
			for(int i=0;i<a.length;i++)
			{
				if(Searchnumber==a[i])
				{
					
					found=true;
					
					System.out.println(Searchnumber+" The given number is present the array 0 present test pass,index of "+i);
					break;
				}else
			
			if(!found)
			{
				
				System.out.println(Searchnumber +"is not present inthe array ,Test Fail");
			}
			
		}
		
	
		
	}

}
