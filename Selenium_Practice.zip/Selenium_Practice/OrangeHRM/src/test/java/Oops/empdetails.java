package Oops;

import java.util.ArrayList;
import java.util.List;

public class empdetails {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		List<Employee>emplist=new ArrayList<Employee>();
		emplist.add(new Employee(1,5000));
		emplist.add(new Employee(2,6000));
		emplist.add(new Employee(3, 7000));
		emplist.add(new Employee(4,80000));
		
		
		System.out.println(emplist.size());
		
		
		
		
	}

}
