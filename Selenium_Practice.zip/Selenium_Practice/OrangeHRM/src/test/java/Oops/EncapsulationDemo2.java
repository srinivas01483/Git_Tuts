package Oops;

public class EncapsulationDemo2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
  EncapsulationDemo1 e=new EncapsulationDemo1();
  e.setName("Balsani Srinivas");
  e.getName();
  
  e.setPwd("Srinivas!@#");
  e.getName();
  
  e.setDepartement("Quality Analyst");
  e.getDepartement();
  
  e.setSalary(800000);
  e.getSalary();
  
  
  e.setGender('M');
  e.getGender();
  System.out.println(e.getName() + " "+e.getPwd() + " " +e.getDepartement() + " "+e.getSalary() + " "+ e.getGender());
	}
}

