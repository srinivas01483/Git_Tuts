package Oops;

import java.util.ArrayList;
import java.util.List;

public class Employee1 {
	
	String id;
	String name;
	public Employee1(String id,String name)
	{
		
List<String>emp=new ArrayList<>();
Employee1.add(name);

	}
	private static void add(String name2) {
		// TODO Auto-generated method stub
		
	}
}
