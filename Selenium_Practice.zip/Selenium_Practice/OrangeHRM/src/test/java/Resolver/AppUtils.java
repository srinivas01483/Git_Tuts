package Resolver;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;

public class AppUtils {
	public static WebDriver driver;
	
	@BeforeTest
	public void setup()
	{
		driver=new FirefoxDriver();
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
		driver.get("file:///C:/Users/balas/AppData/Local/Temp/9d7d5037-a184-4497-8efe-8b380bda426b_AutomationChallenge_2022.zip.26b/QE-index.html");
		
	}
	
	
	@AfterTest
	public void  teardown()
	{
		driver.close();
		
	}
	
}
