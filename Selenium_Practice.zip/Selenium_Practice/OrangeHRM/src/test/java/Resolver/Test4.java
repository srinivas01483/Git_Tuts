package Resolver;

import static org.testng.Assert.assertFalse;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

public class Test4 extends AppUtils{

	@Test
	public void verify_button()
	{
		WebElement chkButtonEnabled=driver.findElement(By.xpath("//*[contains(@id,'test-4')]//button[@class='btn btn-lg btn-primary']"));
		WebElement chkButtonDisbled=driver.findElement(By.xpath("//*[contains(@id,'test-4')]//button[@class='btn btn-lg btn-secondary']"));
		
	boolean buttonEnabled=chkButtonEnabled.isEnabled();
	boolean buttonDisbled=chkButtonDisbled.isEnabled();
	
	Assert.assertTrue(buttonEnabled, "chk button element is enabled");
	
	assertFalse(buttonDisbled,"chk button element is disabled");
	System.out.println(buttonEnabled);
	System.out.println(buttonDisbled);
	
	}
	
}
