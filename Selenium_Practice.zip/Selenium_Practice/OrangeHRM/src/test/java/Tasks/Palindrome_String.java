package Tasks;

import java.util.Scanner;

import org.testng.annotations.Test;

public class Palindrome_String {
	
@Test	
public void checkPalindrome()
{
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter Any Word");
	
	String str=sc.next();
	String org=str;
	
	String rev="";
	
	for(int i=str.length()-1;i>=0;i--)
	{
		
		rev=rev+str.charAt(i);
	}

	if(org.equals(rev))
	{
		System.out.println(org+ " is Plaindrome value");
	}else
	{
		
		System.out.println(org+ "is not a Palindrome value");
	}
}

}
