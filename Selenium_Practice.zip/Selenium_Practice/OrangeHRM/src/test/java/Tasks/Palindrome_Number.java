package Tasks;

import java.util.Scanner;

import org.testng.annotations.Test;

public class Palindrome_Number {

	@Test
	public void checkPalindromeNumber()
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Any Word :");
		int num=sc.nextInt();
		int org_num=num;
		 int rev=0;
		 
		 while(num!=0)
		 {
			 
			 rev=rev*10 +num%10;
			 num=num/10;
		 }
		
		if(org_num==rev)
		{
			
			System.out.println(org_num+ " is a palindrome value");
		}else
		{
			System.out.println(org_num+ "is not  a palindrome value");
		}
	}
}
