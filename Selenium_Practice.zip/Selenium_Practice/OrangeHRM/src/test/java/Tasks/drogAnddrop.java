package Tasks;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

import io.github.bonigarcia.wdm.WebDriverManager;

public class drogAnddrop {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		WebDriverManager.chromedriver().setup();
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		
		driver.get("https://jqueryui.com/");
		driver.findElement(By.linkText("Droppable")).click();
		driver.switchTo().frame(driver.findElement(By.className("demo-frame")));
		
		WebElement srcelement,targelement;
		
		srcelement=driver.findElement(By.id("draggable"));
		targelement=driver.findElement(By.id("droppable"));
		//Thread.sleep(50000);
		Actions act=new Actions(driver);
		act.dragAndDrop(srcelement,targelement);
		act.build().perform();
		
		driver.switchTo().parentFrame();
		driver.findElement(By.linkText("Demos")).click();
		
	}

}
