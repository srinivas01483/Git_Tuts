package Automate_Elements;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;

public class Resolver_Test1 {

	
		public static WebDriver driver;
		public static void main(String[] args) throws InterruptedException {
			// TODO Auto-generated method stub
			driver=new FirefoxDriver();
			driver.manage().window().maximize();
			driver.manage().deleteAllCookies();
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
			driver.get("file:///C:/Users/balas/AppData/Local/Temp/9ad9c0ab-2fa4-400a-ae8c-a8203f5a16e3_AutomationChallenge_2022.zip.6e3/QE-index.html");
         WebElement emailelement=	driver.findElement(By.id("inputEmail"));
       //  emailelement.sendKeys("srinivas@gmail.com");
         boolean  isemaildisplays=emailelement.isDisplayed();
         Assert.assertTrue(isemaildisplays);
        
         WebElement paswordelement=driver.findElement(By.id("inputPassword"));
        boolean isPwddisplays= paswordelement.isDisplayed();
         
        Assert.assertTrue(isPwddisplays,"Password Element not Displayed");
        
        emailelement.sendKeys("srinivasbalasani@gmail.com");
        Thread.sleep(3000);
        paswordelement.sendKeys("srinivas@4791");
        driver.findElement(By.xpath("//button[@type='submit']")).click();
        
        
        
          
	}

}
