package Testcases;

import org.testng.annotations.Test;


public class demo {

	
	public void method1()
	{
		
		System.out.println("hello");
	}
	
}
