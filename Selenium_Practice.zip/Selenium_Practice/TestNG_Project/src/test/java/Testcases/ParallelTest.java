package Testcases;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class ParallelTest {

	WebDriver driver=null;
	
	@Test(invocationCount = 2)
	public void test() throws InterruptedException
	{
		
		System.out.println("Test1 Executed "+Thread.currentThread().getId());	
		
		WebDriverManager.chromedriver().setup();
		
		driver=new ChromeDriver();
		driver.get("http://orangehrm.qedgetech.com");
		Thread.sleep(2000);
	}
	
	@Test
	public void test2()
	{
		
		System.out.println("Test2 Executed "+Thread.currentThread().getId());
WebDriverManager.chromedriver().setup();
		
		driver=new ChromeDriver();
		driver.get("http://google.com");
		
	}
}
