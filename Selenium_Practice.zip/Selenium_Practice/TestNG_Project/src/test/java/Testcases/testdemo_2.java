package Testcases;

import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class testdemo_2 extends testdemo{
	
	@Test
	public void test2()
	{
		
	driver=new ChromeDriver();
	driver.get("http://facebook.com");
	}

}
