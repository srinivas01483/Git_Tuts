package demos;

import org.testng.annotations.Test;

public class SendMailTestCase extends demotest{

	@Test
	public void sendMailTest()
	{
		System.out.println("Send mail test passs");
		
	}
}
