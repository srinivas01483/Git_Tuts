package demos;

public class demotest {
	
	public void launchApp() {
		
		System.out.println("gmail application launched");
	}

	public void closeApp()
	{
		System.out.println("gmail application logout");
		
		
	}
}
