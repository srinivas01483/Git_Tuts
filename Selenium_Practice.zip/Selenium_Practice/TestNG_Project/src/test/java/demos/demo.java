package demos;

import org.testng.annotations.Test;

public class demo {
	@Test
	public void test1()
	{
		
		System.out.println("Test PAss");
	}

}
