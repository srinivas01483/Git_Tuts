package demos;

import org.testng.annotations.Test;

public class ReceiveMailTestCase {
	@Test
	public void ReceiveMailtest() 
	{
		System.out.println("receive test mail pass");
		
	}

}
