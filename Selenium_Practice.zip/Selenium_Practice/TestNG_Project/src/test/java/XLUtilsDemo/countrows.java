package XLUtilsDemo;

import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class countrows {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub

		FileInputStream fi=new FileInputStream("C:\\temp\\testdata.xlsx");
		
		Workbook wb=new XSSFWorkbook(fi);
		Sheet ws1=wb.getSheet("test");
		int sheet_rowcount=ws1.getLastRowNum();
	Row row_colcount=ws1.getRow(0);
	row_colcount.getLastCellNum();
	
	System.out.println(sheet_rowcount);
	System.out.println(row_colcount);
		
		
	}

}
