package XLUtilsDemo;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class demo {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub

		FileInputStream fi=new FileInputStream("C:\\temp\\testdata.xlsx");
		Workbook wb=new XSSFWorkbook(fi);
		wb.createSheet("getsheet");
		FileOutputStream f0=new FileOutputStream("C:\\temp\\testdatademo.xlsx");
				wb.write(f0);
		wb.close();
		
	}

}
