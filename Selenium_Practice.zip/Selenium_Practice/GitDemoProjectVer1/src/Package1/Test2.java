package Package1;

public class Test2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
String hungry="yes";
		
		if(hungry=="yes") 
		{
			System.out.println("Iam Eating....");
			
		}else
		{
			
			System.out.println("I dont eat");
		}
	}

}
