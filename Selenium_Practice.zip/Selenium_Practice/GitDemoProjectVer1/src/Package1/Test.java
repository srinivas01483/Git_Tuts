package Package1;

public class Test {

	public static void main(String[] args) {
		
		String hungry="yes";
		
		if(hungry=="yes") 
		{
			System.out.println("Iam Eating....");
			
		}else
		{
			
			System.out.println("I dont eat");
		}
		
	}

}
