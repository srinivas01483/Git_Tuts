package TestPractice_25042024;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Linktobecheck {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		WebDriverManager.chromedriver().setup();
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
		driver.get("http://google.com");
		
		driver.findElement(By.linkText("Images")).click();
		
		String pgtitle=driver.getTitle();
		
		if(pgtitle.contains("Images"))
		{
			
			System.out.println("Test pass");
		}else
			System.out.println("Test fail");
	}

}
