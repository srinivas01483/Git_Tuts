package TestPractice_25042024;

public class DataTypes {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		byte age=25;
		short marks=1800;
		long salary=1234567890;
		int mobile=900018990;
		float x=1.0222125f;
		double y=10.25d;
		double z=20.50;
		System.out.println(age + " " +marks+ " " +salary+ " " +x);
		
		boolean isworking=true;
		
		char gender='M';
		
		
		System.out.println(isworking);
		System.out.println(gender);
		
		
		//counting no of characters in s string
		
		
		String str="srinivas";
		System.out.println(str.length()); 
		
		//capturing char present at specified position
		
		String str1="Selenium";
		
		for(int i=0;i<=str1.length()-1;i++)
		{
			
			char x1=str1.charAt(i);
			System.out.println(x1);
				
		}
		
		//converting String to lowercase to uppercase
		
		String a,b;
		a="GOoogle";
		b="jaswitha";
		System.out.println(a.toLowerCase());
		System.out.println(b.toUpperCase());
		
		
		//comparing two strings equal
		
		String c="srinivas";
		String d="srinivaS";
		System.out.println(c.equals(d));
		
		
		String e="Welcome google";
		String t="google";
		System.out.println(e.contains(t));		
	}
	

}
