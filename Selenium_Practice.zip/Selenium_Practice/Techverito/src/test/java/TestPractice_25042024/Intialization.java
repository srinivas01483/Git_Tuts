package TestPractice_25042024;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Intialization {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub

		WebDriverManager.firefoxdriver().setup();
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		driver.manage().timeouts().implicitlyWait(20,TimeUnit.SECONDS);
		driver.get("http://orangehrm.qedgetech.com");
		
		driver.findElement(By.id("txtUsername")).sendKeys("Admin");
		driver.findElement(By.id("txtPassword")).sendKeys("Qedge123!@#");
		driver.findElement(By.id("btnLogin")).click();
		
		driver.findElement(By.linkText("Admin")).click();
		driver.findElement(By.linkText("User Management")).click();
		driver.findElement(By.linkText("Users")).click();
		
		driver.findElement(By.xpath("//input[@id='btnAdd']")).click();
		
		WebElement rolelist=driver.findElement(By.id("systemUser_userType"));
		
		Select role=new Select(rolelist);
		role.selectByVisibleText("Admin");
		
		driver.findElement(By.xpath("//input[contains(@id,'empName')]")).sendKeys("Balasani srinivas");
		driver.findElement(By.id("systemUser_userName")).sendKeys("galaxy125");
		driver.findElement(By.id("systemUser_password")).sendKeys("Qedge123!@#");
		Thread.sleep(2000);
		driver.findElement(By.id("systemUser_confirmPassword")).sendKeys("Qedge123!@#");
		
		driver.findElement(By.id("btnSave")).click();
		
		driver.findElement(By.id("searchSystemUser_userName")).sendKeys("galaxy125");
		driver.findElement(By.id("searchBtn")).click();
		
		
		WebElement resulttable=driver.findElement(By.id("resultTable"));
		List<WebElement>rows=resulttable.findElements(By.tagName("tr"));
		
		for(int i=1;i<rows.size();i++)
		{
			
			List<WebElement>cols=rows.get(i).findElements(By.tagName("td"));
			
			for(WebElement userlist:cols)
			{
				String username=userlist.getText();
				
				if(username.equalsIgnoreCase("galaxy125"))
				{
					System.out.println("test pass");
					break;
				}
				else
				{
						
						System.out.println("test fail");
					}
						
				}
			}
			
		}
		
		
		
		
	}


