package TestPractice_25042024;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import io.github.bonigarcia.wdm.WebDriverManager;

public class dropdownlist {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		WebDriverManager.chromedriver().setup();
		WebDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
		driver.get("http://primusbank.qedgetech.com");
		//select value from dropdownlist
		
		String item_tobe_selected="Muruti";
		
		WebElement branchelement=driver.findElement(By.id("drlist"));
		
		Select branch=new Select(branchelement);
			
	try {
		
		branch.selectByVisibleText(item_tobe_selected);
		
		System.out.println(item_tobe_selected +" item present in the list test pass");
		
	} catch (Exception e) {
		System.out.println(item_tobe_selected +" item not present in the list test fail");
		
	}
	
	}
	
	

}
