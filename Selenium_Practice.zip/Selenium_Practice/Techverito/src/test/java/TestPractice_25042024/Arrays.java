package TestPractice_25042024;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Arrays {

	public static void main(String[] args) {

	// TODO Auto-generated method stub
		
		ArrayList<String>vehiclelist=new ArrayList<String>();
		vehiclelist.add("v1");
		vehiclelist.add("v2");
		vehiclelist.add("v3");
		vehiclelist.add("v4");

		System.out.println(vehiclelist.size());
		
		for(String data:vehiclelist)
		{
			if(data.equalsIgnoreCase("v2"))
			{
				System.out.println(data);
				break;
			}
			
		}
		
			}
}
