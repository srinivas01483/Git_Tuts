package testcases;

import org.testng.Assert;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import libraries.LoginPage;
import utils.Apputils;

public class AdminloginTestwithValidData extends Apputils {

	@Parameters({"adminuid","adminpwd"})
@Test
	public void checkAdminlogin(String uid,String pwd)
	{
		LoginPage lp=new LoginPage();
		lp.login(uid,pwd);
		lp.logOut();
		boolean res =lp.isAdminmoduleDisplayed();
		
		Assert.assertTrue(res);
		lp.logOut();
		
		
	}
		
		
	

}
