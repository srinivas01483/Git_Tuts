package stepdefinations;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import com.github.dockerjava.api.model.Driver;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.github.bonigarcia.wdm.WebDriverManager;

public class techverito {

	public static WebDriver driver;

	@Given("i open browser with url {string}")
	public void launchApp(String url) {

		WebDriverManager.chromedriver().setup();
		driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
		driver.get(url);		
	}
	@Then("i should see login module")
	public void i_should_see_login_module() {

		if(driver.findElement(By.xpath("//mat-toolbar-row/div[3]/button[2]/span[2]")).isDisplayed());
		{

			System.out.println("System Displayed login page");
		}

	}
	@When("i click on login button")
	public void i_click_on_login_button() {

		driver.findElement(By.xpath("//mat-toolbar-row/div[3]/button[2]/span[2]")).click();

	}
	@When("i click on Register button")
	public void i_click_on_register_button() throws InterruptedException {
		driver.findElement(By.xpath("//span[contains(text(),'Register')]")).click();
		// Thread.sleep(2000);
	}
	@When("i enter firstname as {string} and lastname as {string}")
	public void i_enter_firstname_as_and_lastname_as(String fname, String lastname) {

		driver.findElement(By.xpath("//form/mat-form-field[1]/div[1]/div/div[2]/input")).sendKeys(fname);
		driver.findElement(By.xpath("//form/mat-form-field[2]/div[1]/div/div[2]/input")).sendKeys(lastname);

	}
	@When("i enter  username as {string} and password as {string} and confirm password as {string}")
	public void i_enter_username_as_and_password_as_and_confirm_password_as(String uname, String pwd, String pwd1) throws InterruptedException {
		driver.findElement(By.xpath("//form/mat-form-field[3]/div[1]/div/div[2]/input")).sendKeys(uname);

		driver.findElement(By.xpath("//form/mat-form-field[4]/div[1]/div/div[2]/input")).sendKeys(pwd); 

		driver.findElement(By.xpath("//form/mat-form-field[5]/div[1]/div/div[2]/input")).sendKeys(pwd1);
		Thread.sleep(2000);
	}

	@When("i enter gender as {string}")
	public void i_enter_gender_as(String string) throws InterruptedException {

		driver.findElement(By.xpath("//input[@type='radio' and @value='Male']")).click();
		Thread.sleep(2000);
	}
	@When("i click on register button")
	public void i_click__register_button() {

		driver.findElement(By.xpath("//form/	mat-card-actions/button/span[2]")).click();

	}
	@Then("i should see login page")
	public void i_should_see_login_page() {
		/*try {
			if(driver.findElement(By.xpath("//mat-card/mat-card-header/div[2]/span")).isDisplayed());

			System.out.println("System Should be Displayed Login Page Credentilas,Test Pass");

		} catch (Exception e) {
			System.out.println("System Should not be Displayed Login Page Credentilas,Test Fail");

		}
*/
		boolean res=driver.findElement(By.xpath("//mat-card/mat-card-header/div[2]/span")).isDisplayed();
		Assert.assertTrue(res);
	}
	@When("close the broswer")
	public void close_the_broswer() {

		driver.close();

	}
	@When("i enter username as {string} and password as {string}")
	public void login(String uname, String pwd) {
		driver.findElement(By.xpath("//form/mat-form-field[1]/div[1]/div/div[2]/input")).sendKeys(uname);
		driver.findElement(By.xpath("//form/mat-form-field[2]/div[1]/div/div[2]/input")).sendKeys(pwd);
	}
	@When("click on login button")
	public void click_on_login_button() {

		driver.findElement(By.xpath("//form[1]/mat-card-actions[1]/button[1]/span[2]")).click();

	}
	@Then("i should see login homepage")
	public void AllcategoriesModuleDisplayed() {

		
		boolean res=driver.findElement(By.linkText("All Categories")).isDisplayed();
		Assert.assertTrue(res);
	}
	@When("i click on logout")
	public void i_click_on_logout() {

		driver.findElement(By.xpath("//mat-toolbar-row/div[3]/a[1]/span[2]")).click();
		driver.findElement(By.xpath("//span[contains(text(),'Logout')]")).click();
	}
	@When("close the browser")
	public void close_the_browser() {
		driver.close();	   
	}

	
	

	@When("i goto Search bar and enter product {string}")
	   public void searchProduct(String productname) throws InterruptedException {
		
		 WebElement SearchBox=driver.findElement(By.xpath("//mat-toolbar-row/div[2]/app-search/form/input"));
		 SearchBox.sendKeys(productname);
		 
		 
		// WebElement selectelement=driver.findElement(By.xpath("/html/body/div[3]/div/div/div/mat-option/span"));
		java.util.List<WebElement>keywordlist =driver.findElement(By.xpath("/html/body/div[3]/div/div")).findElements(By.tagName("mat-option"));
		//System.out.println(keywordlist.size()) ;
		for(WebElement p:keywordlist)
		{
			if(p.getText().equals(productname))
			{
				p.click();
			}
			
		}
	Thread.sleep(2000);

	   }

	@When("click on add to cart button")
	public void click_on_add_to_cart_button() {
	   
		driver.findElement(By.xpath("//span[contains(text(),'Add to Cart')]")).click();
	}
	@Then("to verify selected items should be added to the Cart")
	public void to_verify_selected_items_should_be_added_to_the_cart() {
	  
	}

		
	}

	


