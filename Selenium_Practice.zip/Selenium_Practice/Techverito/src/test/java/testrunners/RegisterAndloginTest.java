package testrunners;

import org.junit.runner.RunWith;

import io.cucumber.junit.Cucumber;
import io.cucumber.testng.CucumberOptions;
import io.cucumber.testng.AbstractTestNGCucumberTests;

//@RunWith(Cucumber.class)
@CucumberOptions(features="featurefiles/register&login.feature",
glue="stepdefinations",
dryRun = false ,
plugin = {"pretty","html:Reports/login.html"}
,tags="@tag1")
//plugin = {"com.cucumber.listener.ExtentCucumberFormatter:target/html/ExtentReport.html"})
public class RegisterAndloginTest extends AbstractTestNGCucumberTests  {

}
