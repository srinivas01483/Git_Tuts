package test;

import static org.testng.Assert.assertTrue;

import java.io.IOException;
import java.time.Duration;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;
import util.DataUtil;
import util.MyXLSReader;

public class Login {
	
	 WebDriver driver;
	
	@AfterMethod
	public void closeBrowser() {
		driver.quit();
		
	}
	@Test(dataProvider ="dataSupplier")
	public void testlogin(String username,String password)
	{
		WebDriverManager.chromedriver().setup();
		driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
		driver.get("https://tutorialsninja.com/demo");
		
		driver.findElement(By.xpath("//span[contains(text(),'My Account')]")).click();
		driver.findElement(By.linkText("Login")).click();
		driver.findElement(By.id("input-email")).sendKeys(username);
		driver.findElement(By.id("input-password")).sendKeys(password);
		driver.findElement(By.xpath("//input[@type='submit']")).click();
		
		Assert.assertTrue(driver.findElement(By.linkText("Edit your account information")).isDisplayed());
		
	}
	@DataProvider
	public Object[] dataSupplier() throws Exception  {
		
		Object[][]data = null;
		try {
			MyXLSReader xlreader=new MyXLSReader("src\\test\\resources\\TutorialsNinja.xlsx");
			data=DataUtil.getTestData(xlreader,"LoginTest","Data");
			
		
			
		} catch (Throwable e) {
			e.printStackTrace();
		}
		return data;
			
		
		
			}

}
