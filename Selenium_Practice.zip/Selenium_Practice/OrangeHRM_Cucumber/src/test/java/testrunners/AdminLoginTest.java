package testrunners;

import org.junit.runner.RunWith;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
import io.cucumber.testng.AbstractTestNGCucumberTests;

@RunWith(Cucumber.class)
@CucumberOptions(
		features="featurefiles/adminlogin.feature",
		glue ="stepdefinations",
		dryRun=false,
		tags ="@tag1",
				plugin = {"pretty","html:Reports/login.html"})
		//plugin = "com.cucumber.listener.ExtentCucumberFormatter:reports/loginresult.html")
public class AdminLoginTest  {

}
