package stepdefinations;

import static org.testng.Assert.assertTrue;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.github.bonigarcia.wdm.WebDriverManager;

public class OrangeHRM {
	public static WebDriver driver;
	
	@Given("i open browser with {string}")
	public void launchApp(String url) {
	WebDriverManager.chromedriver().setup();
	driver=new ChromeDriver();
	driver.manage().window().maximize();
	driver.manage().deleteAllCookies();
	driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(2000));
	driver.get(url);	
	}

	@Then("i should see login page")
	public void i_should_see_login_page() {
boolean res=driver.findElement(By.id("btnLogin")).isDisplayed();
		Assert.assertTrue(res);
	}

	@When("i enter username as {string}")
	public void i_enter_username_as(String username) {
		
		driver.findElement(By.id("txtUsername")).sendKeys(username);

	}

	@When("i enter password as {string}")
	public void i_enter_password_as(String password) {

		driver.findElement(By.id("txtPassword")).sendKeys(password);
	}

	@When("i enter login button")
	public void i_enter_login_button() {
		driver.findElement(By.id("btnLogin")).click();
		
	}

	@Then("i should see admin module")
	public void i_should_see_admin_module() {
		
		boolean res=driver.findElement(By.linkText("Admin")).isDisplayed();
		assertTrue(res);
	}

	@When("i click logout")
	public void i_click_logout() throws InterruptedException {
		
		driver.findElement(By.partialLinkText("Welcome")).click();
		//Thread.sleep(2000);
		driver.findElement(By.xpath("//div[1]/div[9]/ul/li[4]/a")).click();
	}

	@When("i close browser")
	public void i_close_browser() {
		driver.close();
	}
	
	@Then("i should see error message")
	public void i_should_see_error_message() {
		
		boolean res=driver.findElement(By.id("spanMessage")).isDisplayed();
		Assert.assertTrue(res);
	   
	}


}
