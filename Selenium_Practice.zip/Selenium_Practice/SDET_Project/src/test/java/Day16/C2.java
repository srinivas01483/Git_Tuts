package Day16;

public class C2 {

	int z=300;
	void m3()
	{
		
		System.out.println("This is m3 method in C2 "+z);
	}
	
}
