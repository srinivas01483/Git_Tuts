package Day16;

interface Shape
{
int length=20;  //static and final varaibles default
int width=30;
int height=60;

void circle();

default void square()
{
	System.out.println("This is sqaure default method....");
}

static void rectangle()
{
	
System.out.println("This is rectangle static method");
}

}
 public  class Interfacedemo implements Shape{
	
	 
	 public void circle()
	 {
		 
		 System.out.println("This is circle method");
	 }
	 
	 void polygon()  //polygon method presets in interface class i.e by interface we can invoke method
	 {
		 
		 System.out.println("This is polygon inetrface demo");
	 }
	 
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Interfacedemo i=new Interfacedemo();
		/*
		i.square();
		i.circle();
		Shape.rectangle();
	*/
		
		Shape s=new Interfacedemo();
		s.circle();
		s.square();
		Shape.rectangle();  //static method
		i.polygon();
		
		
		
	}

	

 }


