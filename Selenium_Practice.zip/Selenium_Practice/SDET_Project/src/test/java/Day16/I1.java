package Day16;

public interface I1 {
	
	int x=100;
	abstract void m1();

}
