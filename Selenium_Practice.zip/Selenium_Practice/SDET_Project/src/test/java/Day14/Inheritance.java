package Day14;

class A
{
	
int a=100;

void display()
{
	

System.out.println(a);}

}

class B extends A    //single inheritance
{
	int b;
	
	void show()
	{
		
		System.out.println(b);
	}
}


class C extends B  //Multilevel inheritance
{
	
int c=300;
void print()
{
	
System.out.println(c);

}
}



public class Inheritance {

	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
/*
		B bobj=new B();
		bobj.show();
		bobj.display();
		*/
		
		C cobj=new C();
		cobj.display();
		cobj.b=400;
		cobj.show();
		 cobj.c=500;
		cobj.print();
		
	}

}
