package TEST.One;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

import javax.swing.text.html.HTMLDocument.HTMLReader.CharacterAction;

import org.apache.commons.lang3.RandomStringUtils;

public class UST_Interview {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//duplicate words in string 
		
		
		String random=RandomStringUtils.randomAlphanumeric(10);
		System.out.println(random);
				
		}

}
