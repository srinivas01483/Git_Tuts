package TEST.One;

import java.util.HashMap;
import java.util.Map;

public class Interview {

	public static void main(String[] args) {
		// TODO Auto-generated method stub



		String str="srinivas";
		
		String print="";
		
		char[] chars=str.toCharArray();
		
		int size=chars.length;
		
		System.out.println(chars.length);
		
		for(int i=size-1;i>size-4;i--)
		{
			
			print=chars[i]+print;
			
		}
		
		System.out.println(print);
			}

}
