package Day17.pack1;

import Day17.Test1;

public class Test3 extends Test1{

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Test3 t1=new Test3();
		int a3=t1.a;
		System.out.println(a3);
		
		t1.m3();
		
		System.out.println(t1.w);
		t1.m4();
	}

}
