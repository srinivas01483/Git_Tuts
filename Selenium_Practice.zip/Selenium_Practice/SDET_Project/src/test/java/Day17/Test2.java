package Day17;

public class Test2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Test1 t=new Test1();
		
		t.m2(100,200);
		
	}

}
