package Day17;

public class Test1 {

	private int x=100;
 
	private int y=200;
	
	protected int a=500;
	int b=600;
	
	public int w=5000;
	
	private void m1()
	{
		
		System.out.println("This is M1 private method");
	}
	
	void m2(int a,int b)
	{
		
		System.out.println(a+b);
	}
	
	protected void m3()
	{
		
		System.out.println("This is Protected method");
	}
	
	public void m4()
	{
		
		System.out.println("This is Public method");
	}
	public static void main(String[] args)  //Private accmodifiers
	{
		Test1 t=new Test1();
		int x1=t.x=200;
		System.out.println(x1);
		t.m1();
		t.y=500;
		System.out.println(t.y);
		
	}
	
}

