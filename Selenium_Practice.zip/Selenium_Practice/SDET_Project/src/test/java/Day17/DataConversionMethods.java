package Day17;

public class DataConversionMethods {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	// convert String-->int
		
	//	String s="Welecome";   //String value must contain numeric data
		
		String s1="101";
		String s2="102";
		
		System.out.println(Integer.parseInt(s1)+Integer.parseInt(s2));
		
		System.out.println(s1.concat(s2));/// concatination
		
		
		//String-->double
		
		String s3="105.20";
		double d=Double.parseDouble(s3);
		System.out.println(d);
		
		//String-->boolean
		String s4="True";
		System.out.println(Boolean.parseBoolean(s4));
		
		//Convert Primite data type into String
		int a=10;
		double b=20.5;
		char c='M';
		boolean bb=true;
		
		String a1=String.valueOf(a);
		System.out.println(a1);
		
		String a2=String.valueOf(b);
		System.out.println(a2);
		
		System.out.println(String.valueOf(bb));
		System.out.println(String.valueOf(c));
		
		
	}

}
