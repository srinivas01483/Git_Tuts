package Package_060624;

import java.awt.Window;
import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.internal.invokers.AbstractParallelWorker.Arguments;

public class JavaSriptExecutormain {

	public static void main(String[] args) {
		
		System.setProperty("webdriver.chrome.driver","C:\\Users\\balas\\OneDrive\\Documents\\chromedriver.exe");
		WebDriver driver=new FirefoxDriver();
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
		
		driver.get("https://testautomationpractice.blogspot.com/");
		
		//WebElement inputbox=driver.findElement(By.id("name"));
		
		JavascriptExecutor js=(JavascriptExecutor)driver;
		//js.executeScript("arguments[0].setAttribute('value','john')", inputbox);
		
		//driver.findElement(By.id("email")).click();
	
		/*
		
		WebElement emailbox=driver.findElement(By.xpath("//input[@id='male']"));
		js.executeScript("arguments[0].click()",emailbox);
		
		
		
		
		
		// Scroll window page upto pixels element
		
		
		js.executeScript("window.scrollBy(0,1500)", "");
		System.out.println(js.executeScript("return window.pageYoffset;"));
		
		// Scroll window page upto visible element
		
		WebElement resielement=driver.findElement(By.xpath("//h3[@class='ui-widget-header']"));
		
		js.executeScript("arguments[0].scrollIntoView();", resielement);
		
		*/
		
		
		
		js.executeScript("window.scrollBy(0,document.body.scrollHeight)");
		
	}

}
