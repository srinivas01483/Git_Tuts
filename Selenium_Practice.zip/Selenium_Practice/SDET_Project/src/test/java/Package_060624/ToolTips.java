package Package_060624;

import java.io.File;
import java.io.IOException;
import java.time.Duration;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

public class ToolTips {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub


		System.setProperty("webdriver.chrome.driver","C:\\Users\\balas\\OneDrive\\Documents\\chromedriver.exe");
		WebDriver driver=new FirefoxDriver();
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
		
		//driver.get("https://testautomationpractice.blogspot.com/");
		
		driver.get("https://omayo.blogspot.com");
	String element=	driver.findElement(By.xpath("//input[@type='submit']")).getAttribute("title");
	System.out.println(element);
	
	//takescreenshot
	
	TakesScreenshot ts=(TakesScreenshot)driver;
	File srcfile=ts.getScreenshotAs(OutputType.FILE);
	File targfile=new File("B:\\Srinivas\\Testing Material\\Selenium_Course\\SDET\\defect.bmp");
	FileUtils.copyFile(srcfile, targfile);

	//	System.out.println(driver.findElement(By.xpath("//input[@type='submit']")).getAttribute("title"));
		//driver.close();
	}

}
