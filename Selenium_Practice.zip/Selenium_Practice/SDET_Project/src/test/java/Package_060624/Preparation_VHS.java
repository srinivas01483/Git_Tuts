package Package_060624;

import java.util.ArrayList;
import java.util.Scanner;

import Interview_Preparation.Arraylist;
import Interview_Preparation.SwitchCase;

public class Preparation_VHS {

	public static void main(String[] args) {
	// TODO Auto-generated method stub
		
		
		
		for(int i=100;i>=0;i--)
		{
			
			System.out.println(i);
		}
		}

}
