package Package_060624;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;

import com.beust.jcommander.JCommander.Builder;

public class DragandDrop {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
	
		System.setProperty("webdriver.chrome.driver","C:\\Users\\balas\\OneDrive\\Documents\\chromedriver.exe");
		WebDriver driver=new FirefoxDriver();
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
		
		//driver.get("https://testautomationpractice.blogspot.com/");
		
		driver.get("https://jqueryui.com/");
		driver.findElement(By.linkText("Droppable")).click();
		
		driver.switchTo().frame(driver.findElement(By.xpath("//iframe[@class='demo-frame']")));
		
		Thread.sleep(3000);
		WebElement srcelemnt,targelement;
		srcelemnt=driver.findElement(By.id("draggable"));
		targelement=driver.findElement(By.id("droppable"));
		
		Actions act=new Actions(driver);
		act.dragAndDrop(srcelemnt, targelement);
		
		act.build().perform();
		
		
		
		driver.switchTo().parentFrame();
		
		WebElement linkdemo=driver.findElement(By.linkText("Demos"));
		
		act.moveToElement(linkdemo);
		act.contextClick();
		act.build().perform();
		
		
		
		
		
		
			
	}

}
