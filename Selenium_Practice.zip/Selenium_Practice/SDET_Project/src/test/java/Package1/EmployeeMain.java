package Package1;

public class EmployeeMain {  

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Employee emp=new Employee();  //Object creation
		emp.empid=101;
		emp.empname="Srinivas";
		emp.gender='M';
		emp.salary=50000;
		emp.employeedata();
		
		Employee emp2=new Employee(); 
		emp2.empid=102;
		emp2.empname="shobha";
		emp2.gender='F';
		emp2.salary=40000;
		
		emp2.hno=1-125;
		emp2.vilgname="Peroor";
		
		emp2.employeedata();
		emp2.employeeAddress();

	}

}
