package Package1;

public class Employee {
	
	//Variables
	int empid;
	String empname;
	char gender;
	long salary;
	
	int hno;
	String vilgname;
	
	//Methods
	void employeedata()
	{
		System.out.println(empid+ " "+empname+ " "+gender+ " "+salary);
		
	}
	
	void employeeAddress()
	{
		System.out.println(hno+" "+vilgname);
	}
	
	
}
