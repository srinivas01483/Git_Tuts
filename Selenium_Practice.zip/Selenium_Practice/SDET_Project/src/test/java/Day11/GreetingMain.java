package Day11;

public class GreetingMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Greetings gr=new Greetings();
		gr.m1();
		
		String s=gr.m2();
		System.out.println(s);
		
	gr.m3("John");
	
	String var=gr.m4("Srinivas", 1000);
		System.out.println(var);
		
	}

}
