package Day11;

public class Greetings {
	
	void m1() //No params no return value
	{
		
		System.out.println("Hello");
		
	}	
	
	
	String m2()  //No params return value
	{
		
		return("Hello how are you");
		
	}
	
	
	void m3(String name)
	{
		
		System.out.println("Hello "+name);
	}
	
	String m4(String name,int id)
	{
		
		return("HElllo "+name+ " "+id);
	}

}
