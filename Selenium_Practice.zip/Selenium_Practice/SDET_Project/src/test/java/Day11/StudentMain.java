package Day11;

public class StudentMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		//store data Using object reference Varaible
		/*
		Student stu=new Student();
		stu.sid=102;
		stu.sname="Srinivas";
		stu.grade='A';
		stu.printstudentdata();
		
		
		// Using method we can store data
		stu.setStudentData(101, "jaswitha", 'F');
		stu.printstudentdata();
		
	*/
		//Using construcror 
		
Student stu=new Student(200,"shobha",'F');
stu.printstudentdata();
		
	}
	
	

}
