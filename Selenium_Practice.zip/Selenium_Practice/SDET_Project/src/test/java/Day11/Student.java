package Day11;

public class Student {

	int sid;
	String sname;
	char grade;
	
	void printstudentdata()
	{
		System.out.println(sid+ " "+sname+ " "+grade);
		
	}
	
	void setStudentData(int id,String name,char gr)
	{
		
		sid=id;
		sname=name;
		grade=gr;
		
	}
	
	
	//constructor
	
	Student(int id,String name,char gr)
	{
		
		sid=id;
		sname=name;
		grade=gr;
	}
	
}
