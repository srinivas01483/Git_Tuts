package Day11;

public class Constructordemo {

	int x,y;  // constructor means assifn data to varaibles

	
	/*
	Constructordemo()
	{
		x=1000;
		y=200;
		
	}
	
	Constructordemo(int a,int b)
	{
		x=a;
		y=b;
		
	}
	
	void sum(int x,int y)
	{
		
		System.out.println(x+y);
	}
	*/
	void m1()
	{
		System.out.println(x+y);
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//Constructordemo cd=new Constructordemo();  //invoke deafault constructor
		
		Constructordemo cd=new Constructordemo();
		cd.x=100;
		cd.y=800;
		cd.m1();
		//cd.sum();
		
		
		
	}

}
