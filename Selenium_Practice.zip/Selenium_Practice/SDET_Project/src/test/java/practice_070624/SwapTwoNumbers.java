package practice_070624;

public class SwapTwoNumbers {

	
	
	
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		
		
		
	}

}
