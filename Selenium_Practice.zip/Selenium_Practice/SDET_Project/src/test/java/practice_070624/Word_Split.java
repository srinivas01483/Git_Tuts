package practice_070624;

public class Word_Split {

	public static void main(String[] args) {
		
		
		//find second largest number in the array
		
		int arr[]= {1,2,3,4,6};
		int temp;
		
		for(int i=0;i<arr.length;i++)
		{
			for(int j=i+1;j<arr.length;j++)
			{
				if(arr[i]>arr[j])
				{
						temp=arr[i];//20
						arr[i]=arr[j];
					temp=arr[j];
				}
			}
			
			
		}
	
		System.out.println("Second largest number in array is "+arr[1]);
		
	}

}
