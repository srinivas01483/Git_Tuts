package practice_070624;

public class faherhit {

	public static void main(String[] args) {


		String str="hello";
		
		StringBuilder result=new StringBuilder();
		
		for(int i=0;i<str.length();i++)
		{
			
			char currentchar=str.charAt(i);
			
if(result.indexOf(String.valueOf(currentchar))==-1)
{
	
result.append(currentchar);
}
				
		}
		
		System.out.println("after removing"+result.toString());
		
		
			}
}