package practice_070624;

public class StudentMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Student.id=200;
Student.name="Srinivas";
Student.studentdetails();
	}

}
