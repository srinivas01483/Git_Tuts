package practice_070624;

public class Studentdata {

	int x,y;
	
	
	public Studentdata(int x,int y) {
		
		this.x=x;
		this.y=y;
		
	}
	
	void studentsMarks(int x,int y)
	{
		
		System.out.println(x+y);
	}
	
	
	void studentMarks()
	{
		System.out.println(x+y);
	}
	
	
	public static void main(String[] args)
	{
		Studentdata sm=new Studentdata(500, 800);
		sm.studentMarks();
		
	}
}
