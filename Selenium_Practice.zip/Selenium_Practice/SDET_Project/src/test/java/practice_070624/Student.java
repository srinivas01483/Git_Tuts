package practice_070624;

public class Student {

	public static String name;
	public static int id;
	public static String section;
	
	public Student(String name,int id,String section)
	{
		this.name=name;
		this.id=id;
		this.section=section;
		
	}
	
	public static void studentdetails()
	{
		System.out.println(name+ " "+id+ " "+section);
		
		
	}
	

}
