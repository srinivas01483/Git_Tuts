package practice_070624;

public class encapsulationmain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		encapsulationdemo en=new encapsulationdemo();
		en.getName();
		en.setName("Srinivas");
		
		en.getId();
		en.setId(1023);
		
		System.out.println(en.getId());
		System.out.println(en.getName());
		 
	}

}
