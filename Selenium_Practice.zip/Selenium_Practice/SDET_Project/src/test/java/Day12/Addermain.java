package Day12;

public class Addermain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Adder ad=new Adder();
		ad.sum();
		ad.sum(10, 250);
		ad.sum(10, 10.50);
		ad.sum(10.52, 10);
		ad.sum(10,20, 100);
	}

}
