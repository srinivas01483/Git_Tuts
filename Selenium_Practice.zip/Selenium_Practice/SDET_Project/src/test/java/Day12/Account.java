package Day12;

public class Account {

	private int accid;
	private String accname;
	 private int amount;
	public int getAccid() 
	{
		return accid;
	}
	public void setAccid(int accid) 
	{
		this.accid = accid;
	}
	public String getAccname() 
	{
		return accname;
	}
	public void setAccname(String accname)
	{
		this.accname = accname;
	}
	public int getAmount() 
	{
		return amount;
	}
	public void setAmount(int amount) 
	{
		this.amount = amount;
	}
	
	
}
