package Day12;

public class BoxMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	
		//Box b=new Box();
		//Box b=new Box(10.5,20.5,30.5);
		Box b=new Box(20);
		double v=b.volume();
		System.out.println(v);
		
		
		
	}

}
