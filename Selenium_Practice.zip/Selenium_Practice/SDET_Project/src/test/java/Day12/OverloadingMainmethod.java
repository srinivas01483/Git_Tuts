package Day12;

public class OverloadingMainmethod {

	
	void main()
	{
		System.out.println("Hello");
		
	}
	
	void main(String a)
	{
		System.out.println("Hello"+a);
	}
	
	void main(String f,String l)
	{
		System.out.println(f+ " "+l);
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		OverloadingMainmethod ov=new OverloadingMainmethod();
		ov.main();
		ov.main("John");
		ov.main("Srinivas", "Balasani");
		
	}

}
