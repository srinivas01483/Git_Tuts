package Day12;

public class AccountMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Account acc=new Account();
		acc.setAccid(123);
		acc.setAccname("Srinivas");
		acc.setAmount(50000);
		
		System.out.println(acc.getAccid() );
		System.out.println(acc.getAccname());
		System.out.println(acc.getAmount());
		
		acc.setAccid(124);
		acc.setAccname("Shobha");
		acc.setAmount(60000);
		
		System.out.println(acc.getAccid());
		System.out.println(acc.getAccname());
		System.out.println(acc.getAmount());
	
	}

}
