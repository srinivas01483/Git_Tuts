package Interview_Preparation;

public class DataTypes {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		String s="Selenium";
		System.out.println(s.length());
		
       char s1=s.charAt(4);
       System.out.println(s1);
       
    String s2  = s.toLowerCase();
    
    System.out.println(s2);
		
	String p="SELENIUM";
	
	System.out.println(s.toUpperCase().equals(p));
	
	System.out.println(s.equalsIgnoreCase(p));
	
	
	String exptitle,acttitle;
	exptitle="gmail";
	acttitle="Gmail";
	
	System.out.println(exptitle.equalsIgnoreCase(acttitle));
	
	String expurl,acturl;
	expurl="google";
	acturl="Welecome to google";
	System.out.println(acturl.contains(expurl));
	
	
	}

}
