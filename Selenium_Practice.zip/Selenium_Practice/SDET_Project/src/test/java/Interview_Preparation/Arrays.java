package Interview_Preparation;

public class Arrays {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String[] Animal= {"Tiger","Lion","Dog","Camel"};
		
		//to get length of array
		
		System.out.println(Animal.length);
		
		//To Get the data from the array by index
		
		/*
		System.out.println(Animal[0]);
		System.out.println(Animal[1]);
		System.out.println(Animal[2]);
		System.out.println(Animal[3]);
		*/
		
		//Replacing Existing Elemn=ent in Array
		
		Animal[2]="Horse";
		
		//Another way to read the data using for loop
		
		for(int i=0;i<Animal.length;i++)
		{
			System.out.println(Animal[i]);;
		}
		
		//Enhanced for loop
		
		for(String Anminallist:Animal)
		{
			System.out.println(Anminallist);
			
		}
	
		//integer data
		
		int[] empid= {101,102,103,104,105,106};
		
		System.out.println("Count of element "+empid.length);
		
		//Replacing existing elemet
		
		empid[5]=108;
		for(Object idlist:empid)
		{
			System.out.println(idlist);
			
			
			char[] course= {'j','T','P'};
			System.out.println(course.length);
			System.out.println(course[1]);
			
		}
		//System.out.println("Count of element after Update "+empid.length);
		
	}
	
	

}
