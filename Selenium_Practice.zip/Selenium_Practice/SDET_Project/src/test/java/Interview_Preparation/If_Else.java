package Interview_Preparation;

import java.util.Scanner;

public class If_Else {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		// Simple if condition
		
		int a=10;
		int b=20;
		
		if(a<b)
		{
			System.out.println("a is smaller than b");
			
		}
		
		int a1=100;
		int b2=20;
		
		if(a<b)
		{
			System.out.println("a1 is smaller than b2");  //nothing will be executed
			
		}
		
		//if_else condition
		
		int x=100;
		int y=20;
		
		if(x>y)
		{
			System.out.println("x is big,Test pass");
		}else
		{
			System.out.println("x is not big,Test fail");

		}
		
		// zcomapre in two strings
		
		String exptitle,acttle;
		exptitle="google";
		acttle="Google";
		
		if(exptitle.equalsIgnoreCase(acttle))
		{
			System.out.println("Both Strings are equal,Test Pass");
		}else
		{
			System.out.println("Both Strings are not equal,Test Fail");
		}
		
		
		//Contails
		
		String exptitle1,acttle1;
		exptitle1="google";
		acttle1="Hello google12";
		
		if(acttle1.contains(exptitle1))
		{
System.out.println("test pass");
		}else
		{
			System.out.println("Test Fail");
		}
		
		
		System.out.println("Enter Any vlaue");
		
		Scanner sc=new Scanner(System.in);
		
		/*
		try {
			int q1=sc.nextInt();
			System.out.println("Enter Q2 value");
			int q2=sc.nextInt();
			System.out.println(q1/q2);
			
		} catch (Exception e) {
			
			System.out.println(" Enter valid number");
			
		}
		finally {
			System.out.println("you enter into finally blcok");
			
		}
		
		*/
		
		int q1=sc.nextInt();
		System.out.println("Enter Q2 value");
		int q2=sc.nextInt();
		
		if(q1>q2)
		{
			System.out.println("q1 is gig");
		}else
			if(q2>q1)
			{
				System.out.println("q2 is big");
				
			}
		
	}
	
	
	
	
	
	

}
