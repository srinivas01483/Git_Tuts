package Interview_Preparation;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class OrangeHRM_LoginScript {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.setProperty("webdriver.chrome.driver","C:\\Users\\balas\\OneDrive\\Documents\\chromedriver.exe");
		WebDriver driver=new FirefoxDriver();
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
		
		/*
		driver.get("http://orangehrm.qedgetech.com");
		
		driver.findElement(By.id("txtUsername")).sendKeys("Admin");
		driver.findElement(By.id("txtPassword")).sendKeys("Qedge123!@#");
		driver.findElement(By.id("btnLogin")).click();
		driver.findElement(By.partialLinkText("Welcome")).click();
		
		//driver.findElement(By.partialLinkText("Welcome")).click();
		driver.findElement(By.linkText("Logout")).click();
		*/
	
		
		//Xpath concepts
		/*
		driver.get("http://facebook.com");
		
		driver.findElement(By.linkText("Create new account")).click();
		driver.findElement(By.cssSelector("input[aria-label='First name']")).sendKeys("Srinivas goud");
		driver.findElement(By.cssSelector("input[name='lastname']")).sendKeys("Balasani");
		driver.findElement(By.xpath("//input[@name='sex' and @value='2']")).click();
		//driver.findElement(By.xpath("//input[starts-with(@id,'u_2_5_')]")).click();
		*/
		
driver.get("http://orangehrm.qedgetech.com");
		
		driver.findElement(By.id("txtUsername")).sendKeys("Admin");
		driver.findElement(By.id("txtPassword")).sendKeys("Qedge123!@#");
		driver.findElement(By.id("btnLogin")).click();
		driver.findElement(By.linkText("PIM")).click();
		driver.findElement(By.linkText("Employee List")).click();
		
		WebElement jobtitledrpdown=driver.findElement(By.id("empsearch_job_title"));
		
		String x="testing";
		Select jbttle=new Select(jobtitledrpdown);
		List<WebElement>jtlist=jbttle.getOptions();
	int jtlistcount=jtlist.size();
	boolean isitem_present = true;
	for(WebElement e:jtlist)
	{
		if(e.getText().equalsIgnoreCase(x))
		{
			isitem_present=false;
			break;
		}if(isitem_present)
		{
			System.out.println(x+" is present in the list , test pass");
		}else
		{
			System.out.println(x+" is not present in the list, test fail");
		}	
	}
		
		
		
	}

}
