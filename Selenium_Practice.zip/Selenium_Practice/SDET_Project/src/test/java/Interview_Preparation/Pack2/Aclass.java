package Interview_Preparation.Pack2;

public class Aclass {
	
	int a=100;
	
	void m31()
	{
		
		System.out.println(a);
	}
	
}


class eclass extends Aclass
{
	
int b=200;

void m21()
{
	
	System.out.println(b);
}

public static void main (String[]args)
{

	eclass e=new eclass();
	e.m21();
	e.m31();

}

}

