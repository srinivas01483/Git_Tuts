package Interview_Preparation;

public class EmployeeData {

	int empid;
	String empname;
	int salary;
	String designation;
	
	
	public EmployeeData(int empid, String empname)
	{
		this.empid = empid;
		this.empname = empname;
	}

	
	void setstudentdata()
	{
		
		
		System.out.println("emp id " +empid+" "+empname+ " "+salary+ " "+designation);
		//System.out.println("emp id " +empid+" "+empname+ " "+salary+ " "+designation);
		
	}
	
	public static void main(String[] args)
	{
		
		EmployeeData emp = new EmployeeData(102,"skskskjsmm");
		EmployeeData emp1 = new EmployeeData(103,"skskskjsmm");
		
		//emp.empid=100;
		//emp.empname="Srinivas";
		//emp.salary=50000;
		//emp.designation="Quality";
		//EmployeeData emp1 = new EmployeeData();
		//emp1.empid=200;
		//emp1.empname="santhosh";
		
		
		
		emp.setstudentdata();
	}
	 
}
