package Interview_Preparation;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class FindElement {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.setProperty("webdriver.chrome.driver","C:\\Users\\balas\\OneDrive\\Documents\\chromedriver.exe");
		WebDriver driver=new FirefoxDriver();
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
		driver.get("https://google.com");
	
	
		driver.navigate().to("http://primusbank.qedgetech.com");
		
		driver.findElement(By.id("personal")).click();
		
		driver.findElement(By.id("idtxt")).sendKeys("Srinivas");
		driver.findElement(By.xpath("//input[@type='password']")).sendKeys("123456");		
		
		
	}

}
