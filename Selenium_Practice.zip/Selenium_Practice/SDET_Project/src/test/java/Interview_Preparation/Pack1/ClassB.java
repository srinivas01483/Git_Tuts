package Interview_Preparation.Pack1;

import net.bytebuddy.implementation.bind.annotation.Super;

public class ClassB extends ClassA{

	
	int b;
	int k=20000;
	
	void m2()
	{
		System.out.println(a+b);
		System.out.println(super.k);
		
	}
	
	
	
	
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ClassB cl=new ClassB();
		cl.a=20;
		cl.b=20;
		
		cl.m2();
		
		ClassC cd=new ClassC();
		cd.a=200;
		cd.cc=300;
		
		cd.m3();
		
	}

}
