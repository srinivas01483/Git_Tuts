package Interview_Preparation.Pack1;

public class ClassC extends ClassA {
		
		 int cc;
		
	void m3()
	{
		System.out.println(cc+a);
		
	}

}
