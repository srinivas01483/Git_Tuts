package Interview_Preparation.Pack1;

public class ClassA {

	int a;
	int k=10000;
	
	void m1()
	{
		
		System.out.println(a);
	}
	
}
