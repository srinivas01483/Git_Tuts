package Interview_Preparation.Pack1;

public class Box {

 double width,depth,height;
 
 
 /*
 Box()
 {
	width=depth=height=0; 
	 
 }	
 
 Box(double width,double depth,double height)
 {
	this.width=width;
	 this.depth=depth;
	 this.height=height;
	 
 }
 
 Box(double l)
 {
	 width=depth=height=l; 
		 
	 
 }
 
 double volume()
 {
	return (width*depth*height);
	 
	 
 }
 
 */
 
 public Box(double w,double d,double h)
 {
	 width=w;
	 depth=d;
	 height=h;
	 
 }
 
 void method(double w,double d,double h)
 {
	 
	 System.out.println(w*d*h);
 }
 
 void m2()
 {
	 System.out.println(width*depth*height);
 }
 }
