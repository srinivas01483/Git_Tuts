package Interview_Preparation.Pack1;

public class encapsulationmain {

	public static void main(String[] args) {
		encapsulation en=new encapsulation();
	
	en.id=100;
	en.setSname("Srinivas");
	en.setMarks(900);
	
	System.out.println(en.id);
	System.out.println(en.getSname());
	}

}
