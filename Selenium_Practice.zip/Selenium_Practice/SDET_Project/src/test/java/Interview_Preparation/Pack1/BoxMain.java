package Interview_Preparation.Pack1;

public class BoxMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	Box b=new Box(2,2,2);
	b.m2();
	b.method(5, 5, 5);
		
		
	}

}
