package Interview_Preparation.Pack1;

public class Empdata {

	int id;
	String name;
	int  salary;
	
	public Empdata(int id,String name,int salary) {
		
		this.id=id;
		this.name=name;
		this.salary=salary;
		
		
	}
	
	
	public void empdetails()
	{
		
		System.out.println("Empid "+id+ "name "+name+ " " +salary);
	}
	public static void main(String[] args)
	{
		Empdata emp=new Empdata(101,"Srinivas", 50000);
		
		Empdata emp1=new Empdata(102,"Srinivas goud", 40000);
		
		emp.empdetails();
		emp1.empdetails();
	}
}
