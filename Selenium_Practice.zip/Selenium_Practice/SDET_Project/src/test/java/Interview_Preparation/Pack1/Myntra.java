package Interview_Preparation.Pack1;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Myntra {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub

		
		System.setProperty("webdriver.chrome.driver","C:\\Users\\balas\\OneDrive\\Documents\\chromedriver.exe");
		WebDriver driver=new FirefoxDriver();

		driver.manage().deleteAllCookies();
		driver.manage().window().maximize();
		driver.get("http://myntra.com");
		
		WebElement searchbar=driver.findElement(By.className("desktop-searchBar"));
		searchbar.click();
		searchbar.sendKeys("shoes");
		
		Thread.sleep(3000);
		
		List<WebElement> autosuggestionlist= driver.findElement(By.className("desktop-group")).findElements(By.tagName("li"));
		
		for(WebElement element:autosuggestionlist)
		{
			//System.out.println(element.getText());
			
			try {
				
				if(element.getText().equals("Shoes Men Nike"))
				{
					element.click();
				}
				
			} catch (Exception e) {
				System.out.println("Element not found");
			}
			
			
		}
		
		
	}

}
