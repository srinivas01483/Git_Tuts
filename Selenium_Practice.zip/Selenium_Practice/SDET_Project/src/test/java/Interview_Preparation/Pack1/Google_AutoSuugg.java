package Interview_Preparation.Pack1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Google_AutoSuugg {

	public static void main(String[] args) throws Exception {
		System.setProperty("webdriver.chrome.driver","C:\\Users\\balas\\OneDrive\\Documents\\chromedriver.exe");
		WebDriver driver=new FirefoxDriver();

		driver.manage().deleteAllCookies();
		driver.manage().window().maximize();
		driver.get("http:/google.com");
		
		
		WebElement searchbar=driver.findElement(By.xpath("//textarea[@title=\"Search\"]"));
		searchbar.click();
		searchbar.sendKeys("selenium");
		
		Thread.sleep(3000);

	}

}
