package Interview_Preparation.Pack1;

import java.util.Scanner;

public class Primenumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.out.println("Enter any value");
		Scanner sc=new Scanner(System.in);
		int num=sc.nextInt();
		
		boolean isprime=true;
		if(num>1)
		{
			for(int i=2;i<=num;i++)
			{
				
				if(num%2==0)
				
				{
					isprime=false;
				}
			}
			
			
		}else
		{
			
			isprime=false;
		}
		
		if(isprime)
		{
			System.out.println(num+ " given number is prime");
			
		}else
		{
			System.out.println(num+ " given number is not a prime");
			
		}
		
		
		//swap two numbers
		
		int a=12,b=10,c;  //a=10 b=12  
		a=a+b; //22
		b=a-b; //
		a=a-b;
		
		System.out.println("ais" +a);
		System.out.println("b is" +b);
	
		
	}

}
