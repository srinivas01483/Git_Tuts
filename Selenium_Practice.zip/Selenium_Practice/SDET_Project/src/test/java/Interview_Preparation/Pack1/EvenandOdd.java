package Interview_Preparation.Pack1;

public class EvenandOdd {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int num=12345666;
		int even_count=0;
		int odd_count=0;
		
		while(num>0)
		{
			
			int rem=num%10;
			
			if(rem%2==0)
			{
				even_count++;
			}else
				
				if(rem!=0)
				{
					odd_count++;
				}
			
			num=num/10;
		}
		System.out.println("Even num is "+even_count);
		System.out.println("odd num is "+odd_count);
	}

}
