package Interview_Preparation.Pack1;

public class StudentData {

	int id;
	String name;
	int marks;
	char gender;
	
	public StudentData(int id,String name,int marks,char gender) {
		
		this.id=id;
		this.name=name;
		this.marks=marks;
		this.gender=gender;
		
	}
	
	public void printdetails()
	{
		System.out.println(id+" "+name+ " "+marks+ " "+gender);
		
		
	}
	
	
	public static void main (String[] args)
	{
		
		StudentData stu=new StudentData(1048, "Jaswitha Sri",559, 'F');
		
		StudentData stu2=new StudentData(1049, "Srinivas", 450, 'M');
		stu.printdetails();
		stu2.printdetails();
		
	}
}
