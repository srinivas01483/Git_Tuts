package Interview_Preparation;

import java.util.ArrayList;
import java.util.Iterator;

public class Arraylist {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub

		ArrayList<String>productlist=new ArrayList<String>();
		
		
		// to add the elements in the arraylist
		
		productlist.add("Produ1");
		productlist.add("Produ2");
		productlist.add("Produ3");
		productlist.add("Produ3");
		productlist.add("Produ4");
		productlist.add("Produ5");
		productlist.add("Produ6");
		
		//to find the size of the array
		
		System.out.println(productlist.size());
		
		//to insert data in the arraylist
		
		productlist.add(3, "Product7");
		
		// to get the data from he arraylist
		
		System.out.println(productlist.get(0));
	/*	
		for(int i=0;i<productlist.size();i++)
		{
			System.out.println(productlist.get(i));
			
		}
		
		//using iterator method to read data in arraylist
		 * 
		 * 
		*/
		
		//Modify element in the arraylist
		productlist.set(3, "Apple");
		
		Thread.sleep(5000);
	Iterator<String> it =productlist.iterator();
	
	while(it.hasNext())
	{
		System.out.println(it.next());
	}
	}

}
