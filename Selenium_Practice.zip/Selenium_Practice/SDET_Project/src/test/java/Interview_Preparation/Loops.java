package Interview_Preparation;

import java.util.ArrayList;
import java.util.List;

public class Loops {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//inti
	/*	
		int i=101;
		
		while(i<=100)
		{
			System.out.println(i);
			i++;
		}
		System.out.println("end of the while loop");
		
		int j=101;
		do
		{
			
		System.out.println(j);	
		j++;
		}while(j<=100);
		
		
		*/
		//print 1-100
	
		
		/*
		for(int k=1;k<=100;k++)
		{
			System.out.println(k);
			
		}
		
		//100-1
		
		for(int m=100;m>=0;m--)
		{
			System.out.println(m);
		}
		
	*/	
		List<String>carlist=new ArrayList<String>();
	carlist.add("car1");
	carlist.add("car2");
	carlist.add("car3");
	carlist.add("car4");
	
	for(String data:carlist)
	{
		System.out.println(data);
		
		if(data.equalsIgnoreCase("car2"))
		{
			break;
		}
		//System.out.println(data);
		
	}
	
	}
	
	

}
