package Interview_Preparation;

import java.util.Scanner;

public class SwitchCase {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.out.println("Enter any value");
		
		String coursecode;
		Scanner sc=new Scanner(System.in);
		coursecode=sc.nextLine();
		
		switch (coursecode.toLowerCase()) {
		case "s":
			System.out.println("selenium");
			break;
			
		case "q":
			System.out.println("qtp");
			break;
		case "j":
			System.out.println("java");
			break;
		default:
			System.out.println("Inavlid course code");
			break;
		}
	}

}
