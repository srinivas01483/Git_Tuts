package Interview_Preparation;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;

public class Action_element {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub

		System.setProperty("webdriver.chrome.driver","C:\\Users\\balas\\OneDrive\\Documents\\chromedriver.exe");
		WebDriver driver=new FirefoxDriver();

driver.get("http://orangehrm.qedgetech.com");
		
		driver.findElement(By.id("txtUsername")).sendKeys("Admin");
		driver.findElement(By.id("txtPassword")).sendKeys("Qedge123!@#");
		driver.findElement(By.id("btnLogin")).click();
		driver.findElement(By.linkText("PIM")).click();
		
		Thread.sleep(2000);
		//WebElement element=driver.findElement(By.linkText("Employee List"));

		Actions act=new Actions(driver);
		act.moveToElement(driver.findElement(By.linkText("Employee List")));
act.contextClick();
act.build().perform();

	}

}
