package Interview_Preparation;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Invoke_Browser {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
/*
		//WebDriverManager.chromedriver().setup();
		System.setProperty("webdriver.chrome.driver","C:\\Users\\balas\\OneDrive\\Documents\\chromedriver.exe");
		WebDriver driver=new FirefoxDriver();
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
		driver.get("http://snapdeal.com");
		
	*/	
		System.setProperty("webdriver.chrome.driver","C:\\Users\\balas\\OneDrive\\Documents\\chromedriver.exe");
		WebDriver driver=new FirefoxDriver();
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
		driver.navigate().to("https://google.com");
		driver.navigate().to("http://Gmail.com");
		/*
		driver.navigate().back();
		driver.navigate().refresh();
		*/
		String pgtitle=driver.getTitle();
		System.out.println(pgtitle);
		
		
		
		
	}

}
