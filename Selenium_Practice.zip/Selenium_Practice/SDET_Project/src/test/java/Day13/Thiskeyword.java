package Day13;

public class Thiskeyword {

	int x;
	int y;
	
	Thiskeyword(int x,int y) {
		/*
		x=a;
		y=b;
		*/
		
		this.x=x;
		this.y=y;
	}
	
	void m1()
	{
		System.out.println(x+y);
		
	}
}
