package Day13;

public class ThiskeywordMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Thiskeyword th=new Thiskeyword(10, 20);
		th.m1();
		
	}

}
