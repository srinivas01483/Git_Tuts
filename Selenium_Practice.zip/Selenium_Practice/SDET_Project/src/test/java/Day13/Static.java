package Day13;

public class Static {

	static int a=10;  //static variable
int b=20; // non static varaible

	
	
	static void m1()
	{
		
		System.out.println("This is the static method");
		
	}
	
	
	void m2()
	{
		System.out.println("Thsi is non static method");
	}
	
	
	/*
	public static void main(String[] args)
	{
		System.out.println(a);
		m1();
		
		Static s=new Static();
		System.out.println(s.b);
		s.m2();
		}
		*/
			
}
