package Day13;

public class StaticMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.out.println(Static.a);
		Static.m1();
		
		Static s=new Static();
		System.out.println(s.b);
		s.m2();
		
	}

}
