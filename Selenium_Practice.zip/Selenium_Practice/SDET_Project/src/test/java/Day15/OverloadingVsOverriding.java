package Day15;

class ABC{
	
	void m1(int a)
	{
		
		
		System.out.println(a);
	}
	
	void m2(int b)
	{
		System.out.println(b);
		
	}
	
}

class XYZ extends ABC
{
void m1(int a)
{
	System.out.println(a*a);   //Overriding

}

void m2(int a,int b)  //Overloading
{
	System.out.println(a+b);
}

}

public class OverloadingVsOverriding {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		XYZ xyzobj=new XYZ();
		xyzobj.m1(123);
		xyzobj.m2(125, 125);
		
		
	}

}
