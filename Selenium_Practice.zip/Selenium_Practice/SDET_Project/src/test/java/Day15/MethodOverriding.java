package Day15;

class Bank{
	
	double roi()
	{
		return 0;
		
	}
	
}

class ICICI extends Bank{

double roi()
{
	return 10;
	

}

class AB extends Bank

{
double roi()
{
	
return 15;
}
	
}
}


public class MethodOverriding {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		//Bank B=new Bank();
		//System.out.println(B.roi());
		
		ICICI i=new ICICI();
		System.out.println(i.roi());
		
		
		
	}

}
