package Day15;

public class TestAnimalMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		Dog d=new Dog();
		d.display();
		d.eat();
	}

}
