package Day15;

public class Animal {

	String colour="White";
	
	void eat()
	{
		
		System.out.println("Eating nothing");
	}
}

class Dog extends Animal
{
	
String colour="Black";
void display()

{
System.out.println(super.colour);
}

void eat()
{
	
	super.eat();
//System.out.println("eating food");	
}

}